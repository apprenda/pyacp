# ResourceAllocationReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**allocated_cpu** | **float** |  | [optional] 
**allocated_memory** | **float** |  | [optional] 
**allocated_storage** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


