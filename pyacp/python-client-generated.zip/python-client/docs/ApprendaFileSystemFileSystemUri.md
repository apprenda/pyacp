# ApprendaFileSystemFileSystemUri

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**driver** | **str** |  | [optional] 
**mount_point** | **list[str]** |  | [optional] 
**path** | **list[str]** |  | [optional] 
**separator** | **str** |  | [optional] 
**parameters** | **dict(str, str)** |  | [optional] 
**parent_uri** | [**ApprendaFileSystemFileSystemUri**](ApprendaFileSystemFileSystemUri.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


