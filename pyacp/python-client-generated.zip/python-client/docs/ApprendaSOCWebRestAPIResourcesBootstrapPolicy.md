# ApprendaSOCWebRestAPIResourcesBootstrapPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**href** | **str** |  | [optional] 
**name** | **str** |  | 
**description** | **str** |  | [optional] 
**is_active** | **bool** |  | [optional] 
**applied_to_windows** | **bool** |  | 
**applied_to_linux** | **bool** |  | 
**is_always_applied** | **str** |  | 
**applied_to_sandbox_stage** | **bool** |  | 
**applied_to_published_stage** | **bool** |  | 
**custom_property_name** | **str** |  | [optional] 
**component_type** | **str** |  | [optional] 
**comparison** | **str** |  | [optional] 
**values** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


