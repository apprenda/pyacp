# Application

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**alias** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**developer_name** | **str** |  | [optional] 
**application_services** | **str** |  | [optional] 
**versions** | [**list[ApprendaRestAPICommonResourcesResourceBase]**](ApprendaRestAPICommonResourcesResourceBase.md) |  | [optional] 
**href** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


