# swagger_client.NewIntegrationApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_all_nodes**](NewIntegrationApi.md#get_all_nodes) | **GET** /api/v1/nodes | Get all nodes
[**get_node_state**](NewIntegrationApi.md#get_node_state) | **GET** /api/v1/nodes/{roleName}/roleState | Get the state of a node


# **get_all_nodes**
> PagedResourceBaseNode get_all_nodes(page_number=page_number, page_size=page_size, node_name=node_name)

Get all nodes

Returns all nodes in the Platform.   See more on [understanding your Platform nodes](/current/Managing-Apprenda-Infrastructure). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NewIntegrationApi()
page_number = 56 # int | The page of results to return. Defaults to 1, the first page (optional)
page_size = 56 # int | Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 (optional)
node_name = 'node_name_example' # str |  (optional)

try: 
    # Get all nodes
    api_response = api_instance.get_all_nodes(page_number=page_number, page_size=page_size, node_name=node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NewIntegrationApi->get_all_nodes: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_number** | **int**| The page of results to return. Defaults to 1, the first page | [optional] 
 **page_size** | **int**| Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 | [optional] 
 **node_name** | **str**|  | [optional] 

### Return type

[**PagedResourceBaseNode**](PagedResourceBaseNode.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_node_state**
> NodeState get_node_state(role_name, node_name)

Get the state of a node

Returns the state of the given node. A nodes state is releated to how healthy and active the node is in Platform activities.  Only valid for Windows and Linux nodes.   See more on [node states](/current/Managing-Apprenda-Infrastructure#maintenancereserved). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NewIntegrationApi()
role_name = 'role_name_example' # str | 
node_name = 'node_name_example' # str | Required. Name of the node

try: 
    # Get the state of a node
    api_response = api_instance.get_node_state(role_name, node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NewIntegrationApi->get_node_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_name** | **str**|  | 
 **node_name** | **str**| Required. Name of the node | 

### Return type

[**NodeState**](NodeState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

