# swagger_client.AuditRecordsApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**audit_records_export**](AuditRecordsApi.md#audit_records_export) | **GET** /api/v1/auditrecords | Get audit logs


# **audit_records_export**
> PagedResourceBaseAuditRecord audit_records_export(search=search, start_time=start_time, end_time=end_time, page_size=page_size, page_number=page_number, sort_order=sort_order, sort_by=sort_by)

Get audit logs

**Requires Platform version 6.8.0 or later**   Returns all audit logs. Use the query paramters to search and sort for your the audit logs you are looking for. Note, you must have audit logs enabled on your Platform.   See more about [audit logs on the Platform](/current/managing-event-logs#Audit Logs).  

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.AuditRecordsApi()
search = 'search_example' # str | Key word to return matching logs (optional)
start_time = '2013-10-20T19:20:30+01:00' # datetime | Return logs after this date (optional)
end_time = '2013-10-20T19:20:30+01:00' # datetime | Return logs before this date (optional)
page_size = 56 # int | Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 (optional)
page_number = 56 # int | The page of results to return. Defaults to 1, the first page (optional)
sort_order = 'sort_order_example' # str | Determines how results will be sorted. Allowed values: ascending, descending. Default: ascending (optional)
sort_by = 'sort_by_example' # str | Field name to use to sort results. Allowed values: UserId, Resource, SourceIP, TenantId, Operation (optional)

try: 
    # Get audit logs
    api_response = api_instance.audit_records_export(search=search, start_time=start_time, end_time=end_time, page_size=page_size, page_number=page_number, sort_order=sort_order, sort_by=sort_by)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling AuditRecordsApi->audit_records_export: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **search** | **str**| Key word to return matching logs | [optional] 
 **start_time** | **datetime**| Return logs after this date | [optional] 
 **end_time** | **datetime**| Return logs before this date | [optional] 
 **page_size** | **int**| Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 | [optional] 
 **page_number** | **int**| The page of results to return. Defaults to 1, the first page | [optional] 
 **sort_order** | **str**| Determines how results will be sorted. Allowed values: ascending, descending. Default: ascending | [optional] 
 **sort_by** | **str**| Field name to use to sort results. Allowed values: UserId, Resource, SourceIP, TenantId, Operation | [optional] 

### Return type

[**PagedResourceBaseAuditRecord**](PagedResourceBaseAuditRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

