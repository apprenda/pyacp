# NodeProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**node_type** | **str** |  | 
**database_provider** | **str** |  | [optional] 
**is_load_manager** | **bool** |  | [optional] 
**is_off_platform** | **bool** |  | [optional] 
**can_host_ui_manager** | **bool** |  | [optional] 
**can_host_storage_manager** | **bool** |  | [optional] 
**hosts_soc** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


