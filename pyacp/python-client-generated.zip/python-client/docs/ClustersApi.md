# swagger_client.ClustersApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_v1_clusters_get**](ClustersApi.md#api_v1_clusters_get) | **GET** /api/v1/clusters | Get all clusters
[**clusters_create**](ClustersApi.md#clusters_create) | **POST** /api/v1/clusters | Add new cluster
[**clusters_delete_by_name**](ClustersApi.md#clusters_delete_by_name) | **DELETE** /api/v1/clusters/{name} | Remove cluster
[**clusters_get_by_name**](ClustersApi.md#clusters_get_by_name) | **GET** /api/v1/clusters/{name} | Get a cluster
[**clusters_update_by_name**](ClustersApi.md#clusters_update_by_name) | **PUT** /api/v1/clusters/{name} | Update a cluster
[**clusters_validate**](ClustersApi.md#clusters_validate) | **GET** /api/v1/clusters/{name}/validate | Validate a cluster


# **api_v1_clusters_get**
> UnpagedResourceBaseCluster api_v1_clusters_get()

Get all clusters

**Requires Platform version 7.0.0 or later.**   Returns a list of all Kubernetes clusters added to the Platform. 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()

try: 
    # Get all clusters
    api_response = api_instance.api_v1_clusters_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ClustersApi->api_v1_clusters_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**UnpagedResourceBaseCluster**](UnpagedResourceBaseCluster.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clusters_create**
> ClusterReportCard clusters_create(cluster)

Add new cluster

**Requires Platform version 7.0.0 or later.**   Adds an exisiting Kubernetes cluster to the Platform.  Note that only one cluster can be added per cloud.   Validation is run on the cluster to make sure it meets the minimum requirements for being part of the Platform. The request will wait for the validation to complete and return a report on how the cluster performed. If some validation steps fail, the cluster will still be added to the Platform, but the errors need to be corrected before you can use the Platform to manage the cluster.  

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()
cluster = swagger_client.Cluster() # Cluster | Required. Cluster to add

try: 
    # Add new cluster
    api_response = api_instance.clusters_create(cluster)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ClustersApi->clusters_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cluster** | [**Cluster**](Cluster.md)| Required. Cluster to add | 

### Return type

[**ClusterReportCard**](ClusterReportCard.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clusters_delete_by_name**
> clusters_delete_by_name(name)

Remove cluster

**Requires Platform version 7.0.0 or later.**    Removes the specified Kubernetes cluster from the Platform. The cluster will not be affected, but you will no longer be able to access it from the Platform.  

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()
name = 'name_example' # str | Required. Name of the cluster

try: 
    # Remove cluster
    api_instance.clusters_delete_by_name(name)
except ApiException as e:
    print("Exception when calling ClustersApi->clusters_delete_by_name: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Required. Name of the cluster | 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clusters_get_by_name**
> Cluster clusters_get_by_name(name)

Get a cluster

**Requires Platform version 7.0.0 or later.**   Returns information about the specified cluster.  

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()
name = 'name_example' # str | Required. Name of the cluster

try: 
    # Get a cluster
    api_response = api_instance.clusters_get_by_name(name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ClustersApi->clusters_get_by_name: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Required. Name of the cluster | 

### Return type

[**Cluster**](Cluster.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clusters_update_by_name**
> ClusterReportCard clusters_update_by_name(name, cluster)

Update a cluster

**Requires Platform version 7.0.0 or later.**    Updates the specified Kubernetes cluster with the information provided. Making a request to this endpoint will update all fields. You should always pass all input values in the body of the request, because any value that is not provided will be updated to the default value. The only exception to this is the password field. You can pass a value of null for that field and it will not be updated.     Validation is run on the cluster to make sure it meets the minimum requirements for being part of the Platform. The request will wait for the validation to complete and return a report on how the cluster performed. If some validation steps fail, the cluster information will still be updated, but the errors need to be corrected before you can use the Platform to manage the cluster.  

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()
name = 'name_example' # str | Required. Original name of the cluster
cluster = swagger_client.Cluster() # Cluster | Required. Cluster to add

try: 
    # Update a cluster
    api_response = api_instance.clusters_update_by_name(name, cluster)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ClustersApi->clusters_update_by_name: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Required. Original name of the cluster | 
 **cluster** | [**Cluster**](Cluster.md)| Required. Cluster to add | 

### Return type

[**ClusterReportCard**](ClusterReportCard.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clusters_validate**
> ClusterReportCard clusters_validate(name)

Validate a cluster

**Requires Platform version 7.0.0 or later.**   Runs validation against the specified Kubernetes cluster. Validation checks the cluster for a valid configuration and minimum requrements to run as part of the Platform. All clusters must pass validation before the Platform can be used to manage it.    The request will return a report on how the cluster performed. Errors need to be corrected before you can use the Platform to manage the cluster. 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ClustersApi()
name = 'name_example' # str | Required. Name of the cluster

try: 
    # Validate a cluster
    api_response = api_instance.clusters_validate(name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ClustersApi->clusters_validate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**| Required. Name of the cluster | 

### Return type

[**ClusterReportCard**](ClusterReportCard.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

