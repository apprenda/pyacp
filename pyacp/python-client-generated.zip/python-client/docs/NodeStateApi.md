# swagger_client.NodeStateApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_node_state**](NodeStateApi.md#get_node_state) | **GET** /api/v1/nodes/{roleName}/roleState | Get the state of a node
[**set_node_state**](NodeStateApi.md#set_node_state) | **PUT** /api/v1/nodes/{roleName}/roleState | Update the state of a node


# **get_node_state**
> NodeState get_node_state(role_name, node_name)

Get the state of a node

Returns the state of the given node. A nodes state is releated to how healthy and active the node is in Platform activities.  Only valid for Windows and Linux nodes.   See more on [node states](/current/Managing-Apprenda-Infrastructure#maintenancereserved). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodeStateApi()
role_name = 'role_name_example' # str | 
node_name = 'node_name_example' # str | Required. Name of the node

try: 
    # Get the state of a node
    api_response = api_instance.get_node_state(role_name, node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodeStateApi->get_node_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_name** | **str**|  | 
 **node_name** | **str**| Required. Name of the node | 

### Return type

[**NodeState**](NodeState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_node_state**
> NodeState set_node_state(node_name, node_state, role_name)

Update the state of a node

Updates a server's state and initiates a state transition.   In the request body, send the state the server will be transitioned to and a reason the server is being transitioned. A server can be placed into the Online, Reserved, or Maintenance states and all state transitions will take affect imediately after a sucessfull request.   See more on [node states](/current/Managing-Apprenda-Infrastructure#maintenancereserved). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodeStateApi()
node_name = 'node_name_example' # str | Required. Name of the node to transition
node_state = swagger_client.NodeState() # NodeState | State to transition the node to
role_name = 'role_name_example' # str | 

try: 
    # Update the state of a node
    api_response = api_instance.set_node_state(node_name, node_state, role_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodeStateApi->set_node_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **node_name** | **str**| Required. Name of the node to transition | 
 **node_state** | [**NodeState**](NodeState.md)| State to transition the node to | 
 **role_name** | **str**|  | 

### Return type

[**NodeState**](NodeState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

