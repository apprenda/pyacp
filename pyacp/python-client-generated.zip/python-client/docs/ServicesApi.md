# swagger_client.ServicesApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_v1_services_encryption_post**](ServicesApi.md#api_v1_services_encryption_post) | **POST** /api/v1/services/encryption | 


# **api_v1_services_encryption_post**
> EncryptionResult api_v1_services_encryption_post(argument)



Encrypt a string for a specified use

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ServicesApi()
argument = swagger_client.EncryptionRequest() # EncryptionRequest | 

try: 
    api_response = api_instance.api_v1_services_encryption_post(argument)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ServicesApi->api_v1_services_encryption_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **argument** | [**EncryptionRequest**](EncryptionRequest.md)|  | 

### Return type

[**EncryptionResult**](EncryptionResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: text/json, application/json
 - **Accept**: text/json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

