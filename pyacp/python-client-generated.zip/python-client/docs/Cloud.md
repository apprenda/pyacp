# Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**root_url** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**infrastructure_provider** | **str** |  | [optional] 
**cloud_type** | **str** |  | [optional] 
**state** | **str** |  | [optional] 
**cache_size** | **int** |  | [optional] 
**href** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


