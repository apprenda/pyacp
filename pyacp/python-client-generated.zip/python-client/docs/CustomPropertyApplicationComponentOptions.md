# CustomPropertyApplicationComponentOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_interfaces** | **bool** |  | [optional] 
**java_web_applications** | **bool** |  | [optional] 
**windows_services** | **bool** |  | [optional] 
**linux_services** | **bool** |  | [optional] 
**databases** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


