# swagger_client.PlatformDatabasesApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api_v1_platformdatabases_db_alias_get**](PlatformDatabasesApi.md#api_v1_platformdatabases_db_alias_get) | **GET** /api/v1/platformdatabases/{dbAlias} | 
[**api_v1_platformdatabases_get**](PlatformDatabasesApi.md#api_v1_platformdatabases_get) | **GET** /api/v1/platformdatabases | 


# **api_v1_platformdatabases_db_alias_get**
> PlatformDatabase api_v1_platformdatabases_db_alias_get(db_alias)



Get a platform database by its alias

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PlatformDatabasesApi()
db_alias = 'db_alias_example' # str | 

try: 
    api_response = api_instance.api_v1_platformdatabases_db_alias_get(db_alias)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PlatformDatabasesApi->api_v1_platformdatabases_db_alias_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **db_alias** | **str**|  | 

### Return type

[**PlatformDatabase**](PlatformDatabase.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **api_v1_platformdatabases_get**
> UnpagedResourceBasePlatformDatabase api_v1_platformdatabases_get()



Get all platform databases

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.PlatformDatabasesApi()

try: 
    api_response = api_instance.api_v1_platformdatabases_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PlatformDatabasesApi->api_v1_platformdatabases_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**UnpagedResourceBasePlatformDatabase**](UnpagedResourceBasePlatformDatabase.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

