# ApprendaRestAPICommonResourcesPagedResourceBaseVersion

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**current_page** | **int** |  | [optional] 
**page_size** | **int** |  | [optional] 
**total_pages** | **int** |  | [optional] 
**total_items** | **int** |  | [optional] 
**items** | [**list[Version]**](Version.md) |  | [optional] 
**next_page** | [**ApprendaRestAPICommonResourcesResourceBase**](ApprendaRestAPICommonResourcesResourceBase.md) |  | [optional] 
**previous_page** | [**ApprendaRestAPICommonResourcesResourceBase**](ApprendaRestAPICommonResourcesResourceBase.md) |  | [optional] 
**href** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


