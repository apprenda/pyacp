# Component

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_type** | **str** |  | [optional] 
**component_name** | **str** |  | [optional] 
**component_id** | **str** |  | [optional] 
**component_alias** | **str** |  | [optional] 
**version_alias** | **str** |  | [optional] 
**application_alias** | **str** |  | [optional] 
**version** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**workloads** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**href** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


