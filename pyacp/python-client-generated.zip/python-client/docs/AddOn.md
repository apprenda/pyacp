# AddOn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alias** | **str** |  | [optional] 
**href** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**version** | **str** |  | [optional] 
**vendor** | **str** |  | [optional] 
**is_enabled** | **bool** |  | [optional] 
**deployment_notes** | **str** |  | [optional] 
**temp_location** | **str** |  | [optional] 
**user** | **str** |  | [optional] 
**password** | **str** | returned null for security | [optional] 
**dev_team_access** | **str** |  | [optional] 
**allowed_dev_teams** | **list[str]** | will be null if Unrestricted dev team access is enabled | [optional] 
**max_instances_per_dev_team** | **float** | will be null if unlimited | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


