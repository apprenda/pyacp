# CustomPropertyDeveloperOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_visible** | **bool** |  | [optional] 
**visibility_options** | [**VisibilityOptions**](VisibilityOptions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


