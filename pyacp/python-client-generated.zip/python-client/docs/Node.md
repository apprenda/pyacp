# Node

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**href** | **str** |  | [optional] 
**state** | [**NodeState**](NodeState.md) |  | [optional] 
**profiles** | [**list[NodeProfile]**](NodeProfile.md) |  | [optional] 
**is_transitioning** | **bool** |  | [optional] 
**transition_reason** | **str** |  | [optional] 
**is_container_running** | **bool** |  | [optional] 
**os_version** | **str** |  | [optional] 
**apprenda_platform_version** | **str** |  | [optional] 
**is_ghost** | **bool** |  | [optional] 
**total_memory** | **int** |  | [optional] 
**total_actual_memory** | **int** |  | [optional] 
**clock_speed** | **int** |  | [optional] 
**processor_count** | **int** |  | [optional] 
**allocated_memory** | **int** |  | [optional] 
**total_storage** | **int** |  | [optional] 
**allocated_storage** | **int** |  | [optional] 
**allocated_cpu** | **int** |  | [optional] 
**architecture** | **float** |  | [optional] 
**cloud_name** | **str** |  | [optional] 
**resource_allocation** | [**ResourceAllocationReport**](ResourceAllocationReport.md) |  | [optional] 
**workloads** | [**ApprendaRestAPICommonResourcesResourceBase**](ApprendaRestAPICommonResourcesResourceBase.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


