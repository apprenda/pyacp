# Workload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workload_id** | **str** |  | [optional] 
**process_id** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**developer_name** | **str** |  | [optional] 
**developer_alias** | **str** |  | [optional] 
**application_alias** | **str** |  | [optional] 
**version_alias** | **str** |  | [optional] 
**component_name** | **str** |  | [optional] 
**component_alias** | **str** |  | [optional] 
**node_name** | **str** |  | [optional] 
**application** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**version** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**component** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**node** | [**ApprendaUtilityRestAPICommonResourcesResourceBase**](ApprendaUtilityRestAPICommonResourcesResourceBase.md) |  | [optional] 
**href** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


