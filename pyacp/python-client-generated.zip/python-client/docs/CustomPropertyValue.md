# CustomPropertyValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**custom_property** | [**ApprendaRestAPICommonResourcesResourceBase**](ApprendaRestAPICommonResourcesResourceBase.md) |  | [optional] 
**values** | **list[str]** |  | [optional] 
**allowed_values** | **list[str]** |  | [optional] 
**default_values** | **list[str]** |  | [optional] 
**allows_multiple_values** | **bool** |  | [optional] 
**allows_custom_values** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


