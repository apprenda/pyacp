# VisibilityOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_editable_by_developer** | **bool** |  | [optional] 
**is_required_for_deployment** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


