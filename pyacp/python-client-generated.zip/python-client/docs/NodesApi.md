# swagger_client.NodesApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_all_nodes**](NodesApi.md#get_all_nodes) | **GET** /api/v1/nodes | Get all nodes
[**get_node_state**](NodesApi.md#get_node_state) | **GET** /api/v1/nodes/{roleName}/roleState | Get the state of a node
[**get_workloads_on_node**](NodesApi.md#get_workloads_on_node) | **GET** /api/v1/nodes/workloads | Get all workloads on a node
[**set_node_state**](NodesApi.md#set_node_state) | **PUT** /api/v1/nodes/{roleName}/roleState | Update the state of a node


# **get_all_nodes**
> PagedResourceBaseNode get_all_nodes(page_number=page_number, page_size=page_size, node_name=node_name)

Get all nodes

Returns all nodes in the Platform.   See more on [understanding your Platform nodes](/current/Managing-Apprenda-Infrastructure). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodesApi()
page_number = 56 # int | The page of results to return. Defaults to 1, the first page (optional)
page_size = 56 # int | Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 (optional)
node_name = 'node_name_example' # str |  (optional)

try: 
    # Get all nodes
    api_response = api_instance.get_all_nodes(page_number=page_number, page_size=page_size, node_name=node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodesApi->get_all_nodes: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page_number** | **int**| The page of results to return. Defaults to 1, the first page | [optional] 
 **page_size** | **int**| Number of results to return in a single request. All results will be grouped into pages of this size. Default: 20 | [optional] 
 **node_name** | **str**|  | [optional] 

### Return type

[**PagedResourceBaseNode**](PagedResourceBaseNode.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_node_state**
> NodeState get_node_state(role_name, node_name)

Get the state of a node

Returns the state of the given node. A nodes state is releated to how healthy and active the node is in Platform activities.  Only valid for Windows and Linux nodes.   See more on [node states](/current/Managing-Apprenda-Infrastructure#maintenancereserved). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodesApi()
role_name = 'role_name_example' # str | 
node_name = 'node_name_example' # str | Required. Name of the node

try: 
    # Get the state of a node
    api_response = api_instance.get_node_state(role_name, node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodesApi->get_node_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **role_name** | **str**|  | 
 **node_name** | **str**| Required. Name of the node | 

### Return type

[**NodeState**](NodeState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_workloads_on_node**
> UnpagedResourceBaseWorkload get_workloads_on_node(node_name)

Get all workloads on a node

Returns all workloads currently running on the node.

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodesApi()
node_name = 'node_name_example' # str | Required. Name of the node

try: 
    # Get all workloads on a node
    api_response = api_instance.get_workloads_on_node(node_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodesApi->get_workloads_on_node: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **node_name** | **str**| Required. Name of the node | 

### Return type

[**UnpagedResourceBaseWorkload**](UnpagedResourceBaseWorkload.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_node_state**
> NodeState set_node_state(node_name, node_state, role_name)

Update the state of a node

Updates a server's state and initiates a state transition.   In the request body, send the state the server will be transitioned to and a reason the server is being transitioned. A server can be placed into the Online, Reserved, or Maintenance states and all state transitions will take affect imediately after a sucessfull request.   See more on [node states](/current/Managing-Apprenda-Infrastructure#maintenancereserved). 

### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NodesApi()
node_name = 'node_name_example' # str | Required. Name of the node to transition
node_state = swagger_client.NodeState() # NodeState | State to transition the node to
role_name = 'role_name_example' # str | 

try: 
    # Update the state of a node
    api_response = api_instance.set_node_state(node_name, node_state, role_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling NodesApi->set_node_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **node_name** | **str**| Required. Name of the node to transition | 
 **node_state** | [**NodeState**](NodeState.md)| State to transition the node to | 
 **role_name** | **str**|  | 

### Return type

[**NodeState**](NodeState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

