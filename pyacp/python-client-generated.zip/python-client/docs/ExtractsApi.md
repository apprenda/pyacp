# swagger_client.ExtractsApi

All URIs are relative to *http://apps.apprenda.myhost/soc*

Method | HTTP request | Description
------------- | ------------- | -------------
[**logs_export**](ExtractsApi.md#logs_export) | **GET** /api/v1/logs/extract.{format} | 


# **logs_export**
> file logs_export(format, search=search, begin=begin, end=end, version_alias=version_alias, app_alias=app_alias, include_platform=include_platform, include_guest_apps=include_guest_apps, rows=rows, page=page)



### Example 
```python
from __future__ import print_statement
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.ExtractsApi()
format = 'format_example' # str | Designates the desired formatting of the log entry extract stream
search = 'search_example' # str | Search term filter to apply to log entries. (optional)
begin = '2013-10-20T19:20:30+01:00' # datetime | Timestamp of the oldest log entry to consider for extract. (optional)
end = '2013-10-20T19:20:30+01:00' # datetime | Timestamp of the newest log entry to consider for extract. (optional)
version_alias = 'version_alias_example' # str | Version Alias of a specific application version to extract logs from. (optional)
app_alias = 'app_alias_example' # str | Application Alias of a specific application to extract logs from. (optional)
include_platform = true # bool | Should platform sourced logs be included in extract. (optional) (default to true)
include_guest_apps = true # bool | Should guest application sourced logs be included in extract. (optional) (default to true)
rows = 3.4 # float | Number of rows per page to return in paged output (optional)
page = 3.4 # float | How many pages of rows should be skipped (optional)

try: 
    api_response = api_instance.logs_export(format, search=search, begin=begin, end=end, version_alias=version_alias, app_alias=app_alias, include_platform=include_platform, include_guest_apps=include_guest_apps, rows=rows, page=page)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ExtractsApi->logs_export: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **format** | **str**| Designates the desired formatting of the log entry extract stream | 
 **search** | **str**| Search term filter to apply to log entries. | [optional] 
 **begin** | **datetime**| Timestamp of the oldest log entry to consider for extract. | [optional] 
 **end** | **datetime**| Timestamp of the newest log entry to consider for extract. | [optional] 
 **version_alias** | **str**| Version Alias of a specific application version to extract logs from. | [optional] 
 **app_alias** | **str**| Application Alias of a specific application to extract logs from. | [optional] 
 **include_platform** | **bool**| Should platform sourced logs be included in extract. | [optional] [default to true]
 **include_guest_apps** | **bool**| Should guest application sourced logs be included in extract. | [optional] [default to true]
 **rows** | **float**| Number of rows per page to return in paged output | [optional] 
 **page** | **float**| How many pages of rows should be skipped | [optional] 

### Return type

[**file**](file.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, text/csv, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

