# AuditRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**timestamp** | **str** |  | [optional] 
**user_id** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**resource** | **str** |  | [optional] 
**original_value** | **str** |  | [optional] 
**new_value** | **str** |  | [optional] 
**event_type** | **str** |  | [optional] 
**source_ip** | **str** |  | [optional] 
**operation** | **str** |  | [optional] 
**details** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


